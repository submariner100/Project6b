All assets are licensed under CC0.

Background, ground, player, rock graphics by Kenney
	http://opengameart.org/content/tappy-plane
	http://kenney.itch.io/kenney-donation

Music by ShwiggityShwag – "8 Bit The Hero"
	http://opengameart.org/content/8-bit-the-hero

Coin sound by Luke.RUSTLD - "10 8Bit Coin Sounds"
	http://opengameart.org/content/10-8bit-coin-sounds

Explosion sound by Luke.RUSTLD - "Bomb Explosion 8bit"
	http://opengameart.org/content/bombexplosion8bit

