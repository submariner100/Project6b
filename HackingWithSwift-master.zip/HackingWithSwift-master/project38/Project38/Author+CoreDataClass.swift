//
//  Author+CoreDataClass.swift
//  Project38
//
//  Created by TwoStraws on 26/08/2016.
//  Copyright © 2016 Paul Hudson. All rights reserved.
//

import Foundation
import CoreData


public class Author: NSManagedObject {

}
